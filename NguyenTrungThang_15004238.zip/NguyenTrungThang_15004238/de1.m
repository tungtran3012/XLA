i1 = imread('barCodesDetection.png');

i2 = uint8(rgb2gray(i1));
j = cvB(i2);

[m,n] = size(j);

A = load('info.txt');
B = load('labelMatrix.txt');

MajorAxisLength = A(:,1);
Orientation = A(:,2);
Eccentricity = A(:,3);

a = ones(length(A),1);

for i=1:length(A)
   if MajorAxisLength(i,1)>0.8 && Orientation(i,1)< -70 && MajorAxisLength(i,1)>= 20 && MajorAxisLength(i,1)<= 120
      a(i,1)=0; 
   end
end

[P,Q]=size(B);
for i=1:length(a)
    for p=1:P
        for q=1:Q
           if a(i,1)==0 && B(p,q)==i
               j(p,q)=0;
           end
        end
    end
end

subplot(1,2,1),imshow(j),title "j";
subplot(1,2,2),imshow(B), title "B";

% Tim thanh phan lien thong
%{ 
visited = false(m,n);
[rows,cols] = size(j);
B = zeros(rows,cols);
ID_counter = 1;

for row = 1 : rows
    for col = 1 : cols
        if j(row,col) == 0
            visited(row,col) = true;
        elseif visited(row,col)
            continue;
        else
         
            stack = [row col];
            
            while ~isempty(stack)
               
                loc = stack(1,:);
                stack(1,:) = [];

              
                if visited(loc(1),loc(2))
                    continue;
                end

                
                
                visited(loc(1),loc(2)) = true;
                B(loc(1),loc(2)) = ID_counter;

                
                [locs_y, locs_x] = meshgrid(loc(2)-1:loc(2)+1, loc(1)-1:loc(1)+1);
                locs_y = locs_y(:);
                locs_x = locs_x(:);

               
                out_of_bounds = locs_x < 1 | locs_x > rows | locs_y < 1 | locs_y > cols;

                locs_y(out_of_bounds) = [];
                locs_x(out_of_bounds) = [];

               
                is_visited = visited(sub2ind([rows cols], locs_x, locs_y));

                locs_y(is_visited) = [];
                locs_x(is_visited) = [];

                is_1 = j(sub2ind([rows cols], locs_x, locs_y));
                locs_y(~is_1) = [];
                locs_x(~is_1) = [];
             
                stack = [stack; [locs_x locs_y]];
            end
            ID_counter = ID_counter + 1;
        end
    end 
end   
%}


function k = cvB(image)
    [m,n]=size(image);
    k = zeros(m,n);  
        for i=1:m
           for j=1:n
                if (image(i,j) <= 120)
                    k(i,j)=1;
                else
                    k(i,j)=0;
                end
           end
        end
end
i = imread('fence.png');
g = imread('noiseSP.png');


subplot(1,2,1), imshow(i);
subplot(1,2,2), imshow(g);
figure;

z1 = i(:,:,1)+g;
z2 = i(:,:,2)+g;
z3 = i(:,:,3)+g;

img = cat(3,z1,z2,z3);
imshow(img);


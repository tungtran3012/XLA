#{
  Cho 2 anh mau (I,J), tien hanh so khop histogram tren 2 anh, cho anh thu 3 (K)
  Hien thi ca 3 anh.
  (I va J phai cung loai anh, vd: cung la anh xam hoac cung la anh mau)
#}

function histMatching(fileNameI, fileNameJ)
  imgI = imread(fileNameI);
  imgJ = imread(fileNameJ);
  
  if length(size(imgI) == 3)
    b = 3; # color image
  elseif length(size(imgI) == 2)
    b = 1; # gray image
  endif
  
  imgK = matchingHistAll(imgI, imgJ, b);
  
  imwrite(uint8(imgK), "remappedImg.jpg");
  
  #subplot(2,2,1), imshow(imgI), title("Original Image");
  #subplot(2,2,2), imshow(imgJ), title("Target Image");
  #subplot(2,2,3:4), imshow(uint8(imgK)), title("Remapped Image");
endfunction

# pdf on 1 channel
function pdfI = pdf(imgI)
  h = zeros(256,1);
  for i = 1:256
    h(i) = sum((imgI==(i-1))(:));
  endfor
  cdfI = h / numel(imgI);
  pdfI = cumsum(cdfI);
endfunction

# matching histogram on 1 channel
function imgK_b = matchingHist1Channel(imgI_b, imgJ_b)
  pdfI = pdf(imgI_b);
  pdfJ = pdf(imgJ_b);
  
  LUT = zeros(256, 1);
  g_J = 0;
  for g_I = 0:255
    while((pdfJ(g_J+1) < pdfI(g_I + 1)) && g_J < 255)
      g_J = g_J + 1;
    endwhile
    LUT(g_I + 1) = g_J;
  endfor
  
  imgK_b = LUT(imgI_b + 1);
endfunction

# matching histogram on all
function imgK = matchingHistAll(imgI, imgJ, b)
  for i = 1:b
    imgK(:,:,i) = matchingHist1Channel(imgI(:,:,i), imgJ(:,:,i));  
  endfor
endfunction
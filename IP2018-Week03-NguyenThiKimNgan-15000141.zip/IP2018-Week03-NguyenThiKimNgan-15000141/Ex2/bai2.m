#{
  So sanh su sai khac khi tang giam do tuong phan
#}

function bai2 (fileName)
  imgI = imread(fileName);
  
  imgJ = contrastChange(double(imgI), 2, 127);  
  imgK = contrastChange(imgJ, 1/2, 127); 
  L = abs(double(imgI) - imgK);
  
  subplot(4,2,1), imshow(imgI), title("Orginal");
  subplot(4,2,3), imshow(uint8(imgJ)), title("Increase Contrast");
  subplot(4,2,5), imshow(uint8(imgK)), title("Decrease Contrast");
  subplot(4,2,7), imshow(uint8(L)), title("diff");
  subplot(4,2,2), plot(histImg(imgI)), title("Orginal"); 
  subplot(4,2,4), plot(histImg2(imgJ)), title("Increase Contrast");
  subplot(4,2,6), plot(histImg2(imgK)), title("Decrease Contrast");
  subplot(4,2,8), plot(histImg2(L)), title("diff");

endfunction

function imgContrast = contrastChange(img, a, s)
  # a < 1: giam do tuong phan
  # a > 1: tang do tuong phan 
  imgContrast = (img - s) .* a + s;
  imgContrast (imgContrast<0) = 0;
  imgContrast (imgContrast>255) = 255;
endfunction

function h = histImg(grayImg)
  h = zeros(256,1);
  for i = 1:255
    h(i) = sum((grayImg == (i-1))(:));
  endfor
endfunction

function h = histImg2 (img) # image not int8
  c = 255/(256-1); # c = A/(n-1)
  maxValue = 256;
  h = zeros(256, 1);
  for i = 1:maxValue
    min = c * (i-1.5);
    max = c * (i-0.5);
    h(i) = sum(((img >= min) & (img < max))(:));
  endfor                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
endfunction